![EYE](https://josd.github.io/images/eye.png)

## triptych

- backward rules use a left arrow `<=`
- forward rules use a right arrow `=>`
- queries use a triangular arrow `|>`

## variables

- only `_:x` blank nodes in triples and quads
- only `?x` quickvars in rules and queries
- quantified `var:x` variables in proofs
